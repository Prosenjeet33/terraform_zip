// Package jsonstate implements methods for outputting a state in a
// machine-readable json format
package jsonstate
