// Package jsonprovider contains types and functions to marshal terraform
// provider schemas into a json formatted output.
package jsonprovider
